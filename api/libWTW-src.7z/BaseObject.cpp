/*
** Copyright (C) 2007-2014, K2T.eu
*/

#include "stdafx.h"
#include "libWTW.h"
#include <cpp/BaseObject.h>
#include <wtwPlugin.h>

void wtw::CBaseObject::release()
{
	delete this;
}

/*
WTW_PTR wtw::CBaseObject::dump(const wchar_t *file)
{
	return E_NOTIMPL;
}
*/