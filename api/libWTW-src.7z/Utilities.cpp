/*
* Copyright (C) 2011, WTW.im Sp. z o.o.
*/

#include "stdafx.h"
#include "libWTW.h"
#include <wchar.h>
#include <cpp/Globals.h>
#include <cpp/Utilities.h>

#pragma warning(disable: 4244)

namespace wtw 
{
	CUtilities::CUtilities()
	{
	};

};