/*
** Copyright (C) 2007-2014, K2T.eu
*/

#include "stdafx.h"
#include <wchar.h>
#include "libWTW.h"
#include <cpp/XmlSax.h>
#include <cpp/Conv.h>
#include <expat.h>

wtw::CXmlSax::CXmlSax()
{
	m_pParser;
}

wtw::CXmlSax::~CXmlSax()
{
	destroy();
}

HRESULT wtw::CXmlSax::create(const wchar_t *pszEncoding, const wchar_t *pszSep)
{
	destroy();

	if (pszEncoding != NULL && pszEncoding[0] == 0)
	{
		pszEncoding = nullptr;
	}

	if (pszSep != NULL && pszSep[0] == 0)
	{
		pszSep = nullptr;
	}

	m_pParser = XML_ParserCreate_MM(pszEncoding, NULL, pszSep);
	if (m_pParser == NULL)
	{
		return MAKE_HRESULT(SEVERITY_ERROR, 0, getErrorCode());
	}

	//XML_SetHashSalt(static_cast<XML_Parser>(m_pParser), rand());
	XML_SetUserData(static_cast<XML_Parser>(m_pParser), (void *) this);

	onPostCreate();
	return S_OK;
}

void wtw::CXmlSax::destroy()
{
	if (m_pParser != nullptr)
	{
		XML_ParserFree((XML_Parser)m_pParser);
	}
	m_pParser = nullptr;
}

HRESULT wtw::CXmlSax::parse(const char *pszBuffer, int nLength, bool bIsFinal)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}

	if (nullptr == pszBuffer)
	{
		return E_INVALIDARG;
	}

	if (nLength < 0)
	{
		nLength = strlen(pszBuffer);
	}

	return XML_Parse(static_cast<XML_Parser>(m_pParser), pszBuffer, nLength, bIsFinal) != 0 ? S_OK : MAKE_HRESULT(SEVERITY_ERROR, 0, getErrorCode());
}

HRESULT wtw::CXmlSax::parse(const wchar_t *pszBuffer, int nLength, bool bIsFinal)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}

	if (nLength < 0)
	{
		nLength = wcslen(pszBuffer);
	}

	char *pBuffer = wtw::CConv::wtou(pszBuffer, nLength);
	nLength = strlen(pBuffer);
	HRESULT ret = XML_Parse(static_cast<XML_Parser>(m_pParser), pBuffer, nLength, bIsFinal) != 0 ? S_OK : MAKE_HRESULT(SEVERITY_ERROR, 0, getErrorCode());
	wtw::CConv::release(pBuffer);
	return ret;
}

HRESULT wtw::CXmlSax::parseBuffer(int nLength, bool bIsFinal)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	return XML_ParseBuffer(static_cast<XML_Parser>(m_pParser), nLength, bIsFinal) != 0 ? S_OK : MAKE_HRESULT(SEVERITY_ERROR, 0, getErrorCode());
}

void *wtw::CXmlSax::getBuffer(int nLength)
{
	assert(m_pParser != NULL);
	return XML_GetBuffer(static_cast<XML_Parser>(m_pParser), nLength);
}

HRESULT wtw::CXmlSax::enableStartElementHandler(bool bEnable)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	XML_SetStartElementHandler(static_cast<XML_Parser>(m_pParser), bEnable ? _startElementHandler : NULL);
	return S_OK;
}

HRESULT wtw::CXmlSax::enableEndElementHandler(bool bEnable)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	XML_SetEndElementHandler(static_cast<XML_Parser>(m_pParser), bEnable ? _endElementHandler : NULL);
	return S_OK;
}

HRESULT wtw::CXmlSax::enableElementHandler(bool bEnable)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	enableStartElementHandler(bEnable);
	enableEndElementHandler(bEnable);
	return S_OK;
}

HRESULT wtw::CXmlSax::enableCharacterDataHandler(bool bEnable)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	XML_SetCharacterDataHandler(static_cast<XML_Parser>(m_pParser),
		bEnable ? _characterDataHandler : NULL);
	return S_OK;
}

HRESULT wtw::CXmlSax::enableProcessingInstructionHandler(bool bEnable)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	XML_SetProcessingInstructionHandler(static_cast<XML_Parser>(m_pParser),
		bEnable ? &_processingInstructionHandler : NULL);
	return S_OK;
}

HRESULT wtw::CXmlSax::enableCommentHandler(bool bEnable)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	XML_SetCommentHandler(static_cast<XML_Parser>(m_pParser), bEnable ? &_commentHandler : NULL);
	return S_OK;
}

HRESULT wtw::CXmlSax::enableStartCdataSectionHandler(bool bEnable)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	XML_SetStartCdataSectionHandler(static_cast<XML_Parser>(m_pParser),
		bEnable ? &_startCdataSectionHandler : NULL);
	return S_OK;
}

HRESULT wtw::CXmlSax::enableEndCdataSectionHandler(bool bEnable)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	XML_SetEndCdataSectionHandler(static_cast<XML_Parser>(m_pParser),
		bEnable ? &_endCdataSectionHandler : NULL);
	return S_OK;
}

HRESULT wtw::CXmlSax::enableCdataSectionHandler(bool bEnable)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	enableStartCdataSectionHandler(bEnable);
	enableEndCdataSectionHandler(bEnable);
	return S_OK;
}

HRESULT wtw::CXmlSax::enableDefaultHandler(bool bEnable, bool bExpand)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	if (bExpand)
	{
		XML_SetDefaultHandlerExpand(static_cast<XML_Parser>(m_pParser),
			bEnable ? &_defaultHandler : NULL);
	}
	else
	{
		XML_SetDefaultHandler(static_cast<XML_Parser>(m_pParser), bEnable ? &_defaultHandler : NULL);
	}
	return S_OK;
}

HRESULT wtw::CXmlSax::enableExternalEntityRefHandler(bool bEnable)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	XML_SetExternalEntityRefHandler(static_cast<XML_Parser>(m_pParser), (bEnable) ? (XML_ExternalEntityRefHandler)&_externalEntityRefHandler : NULL);
	return S_OK;
}

/*
HRESULT wtw::CXmlSax::enableUnknownEncodingHandler(bool bEnable)
{
if (nullptr == m_pParser)
{
return E_NOT_VALID_STATE;
}
XML_SetUnknownEncodingHandler(static_cast<XML_Parser>(m_pParser),
bEnable ? &_unknownEncodingHandler : NULL);
}
*/

HRESULT wtw::CXmlSax::enableStartNamespaceDeclHandler(bool bEnable)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	XML_SetStartNamespaceDeclHandler(static_cast<XML_Parser>(m_pParser),
		bEnable ? &_startNamespaceDeclHandler : NULL);
	return S_OK;
}

HRESULT wtw::CXmlSax::enableEndNamespaceDeclHandler(bool bEnable)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	XML_SetEndNamespaceDeclHandler(static_cast<XML_Parser>(m_pParser),
		bEnable ? &_endNamespaceDeclHandler : NULL);
	return S_OK;
}

HRESULT wtw::CXmlSax::enableNamespaceDeclHandler(bool bEnable)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	enableStartNamespaceDeclHandler(bEnable);
	enableEndNamespaceDeclHandler(bEnable);
	return S_OK;
}

HRESULT wtw::CXmlSax::enableXmlDeclHandler(bool bEnable)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	XML_SetXmlDeclHandler(static_cast<XML_Parser>(m_pParser), bEnable ? &_xmlDeclHandler : NULL);
	return S_OK;
}

HRESULT wtw::CXmlSax::enableStartDoctypeDeclHandler(bool bEnable)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	XML_SetStartDoctypeDeclHandler(static_cast<XML_Parser>(m_pParser),
		bEnable ? &_startDoctypeDeclHandler : NULL);
	return S_OK;
}

HRESULT wtw::CXmlSax::enableEndDoctypeDeclHandler(bool bEnable)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	XML_SetEndDoctypeDeclHandler(static_cast<XML_Parser>(m_pParser),
		bEnable ? &_endDoctypeDeclHandler : NULL);
	return S_OK;
}

HRESULT wtw::CXmlSax::enableDoctypeDeclHandler(bool bEnable)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	enableStartDoctypeDeclHandler(bEnable);
	enableEndDoctypeDeclHandler(bEnable);
	return S_OK;
}

int wtw::CXmlSax::getErrorCode()
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	return XML_GetErrorCode(static_cast<XML_Parser>(m_pParser));
}

HRESULT wtw::CXmlSax::getCurrentByteIndex(long &ret)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	ret = XML_GetCurrentByteIndex(static_cast<XML_Parser>(m_pParser));
	return S_OK;
}

HRESULT wtw::CXmlSax::getCurrentLineNumber(int &ret)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	ret = XML_GetCurrentLineNumber(static_cast<XML_Parser>(m_pParser));
	return S_OK;
}

HRESULT wtw::CXmlSax::getCurrentColumnNumber(int & ret)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	ret = XML_GetCurrentColumnNumber(static_cast<XML_Parser>(m_pParser));
	return S_OK;
}

HRESULT wtw::CXmlSax::getCurrentByteCount(int &ret)
{
	if (nullptr == m_pParser)
	{
		return E_NOT_VALID_STATE;
	}
	ret = XML_GetCurrentByteCount(static_cast<XML_Parser>(m_pParser));
	return S_OK;
}

/*
const char *wtw::CXmlSax::getInputContext(int *pnOffset, int *pnSize)
{
if (nullptr == m_pParser)
{
return nullptr;
}
return XML_GetInputContext(static_cast<XML_Parser>(m_pParser), pnOffset, pnSize);
}
*/

const wchar_t* wtw::CXmlSax::getErrorString()
{
	return XML_ErrorString((::XML_Error)getErrorCode());
}

const wchar_t *wtw::CXmlSax::getVersion()
{
	return XML_ExpatVersion();
}

void wtw::CXmlSax::getVersion(int *pnMajor, int *pnMinor, int *pnRevision)
{
	XML_Expat_Version v = XML_ExpatVersionInfo();
	if (pnMajor)
	{
		*pnMajor = v.major;
	}
	if (pnMinor)
	{
		*pnMinor = v.minor;
	}
	if (pnRevision)
	{
		*pnRevision = v.micro;
	}
}

const wchar_t *wtw::CXmlSax::getErrorString(int nError)
{
	return (const wchar_t*)XML_ErrorString((::XML_Error)nError);
}

void wtw::CXmlSax::onStartElement(const wchar_t *pszName, const wchar_t **papszAttrs)
{
	return;
}

void wtw::CXmlSax::onEndElement(const wchar_t *pszName)
{
	return;
}

void wtw::CXmlSax::onCharacterData(const wchar_t *pszData, int nLength)
{
	return;
}

void wtw::CXmlSax::onProcessingInstruction(const wchar_t *pszTarget,
	const wchar_t *pszData)
{
	return;
}

void wtw::CXmlSax::onComment(const wchar_t *pszData)
{
	return;
}

void wtw::CXmlSax::onStartCdataSection()
{
	return;
}

void wtw::CXmlSax::onEndCdataSection()
{
	return;
}

void wtw::CXmlSax::onDefault(const wchar_t *pszData, int nLength)
{
	return;
}

bool wtw::CXmlSax::onExternalEntityRef(const wchar_t *pszContext, const wchar_t *pszBase, const wchar_t *pszSystemID, const wchar_t *pszPublicID)
{
	return false;
}

/*
bool wtw::CXmlSax::onUnknownEncoding(const wchar_t *pszName, XML_Encoding *pInfo)
{
	return false;
}
*/

void wtw::CXmlSax::onStartNamespaceDecl(const wchar_t *pszPrefix, const wchar_t *pszURI)
{
	return;
}

void wtw::CXmlSax::onEndNamespaceDecl(const wchar_t *pszPrefix)
{
	return;
}

void wtw::CXmlSax::onXmlDecl(const wchar_t *pszVersion, const wchar_t *pszEncoding, bool bStandalone)
{
	return;
}

void wtw::CXmlSax::onStartDoctypeDecl(const wchar_t *pszDoctypeName, const wchar_t *pszSysID, const wchar_t *pszPubID, bool bHasInternalSubset)
{
	return;
}

void wtw::CXmlSax::onEndDoctypeDecl()
{
	return;
}

void wtw::CXmlSax::onPostCreate()
{
}

void wtw::CXmlSax::_startElementHandler(void *cbData, const wchar_t *pszName, const wchar_t **papszAttrs)
{
	CXmlSax *pClass = static_cast <CXmlSax *>(cbData);
	pClass->onStartElement(pszName, papszAttrs);
}

void wtw::CXmlSax::_endElementHandler(void *cbData, const wchar_t *pszName)
{
	CXmlSax *pClass = static_cast <CXmlSax *>(cbData);
	pClass->onEndElement(pszName);
}

void wtw::CXmlSax::_characterDataHandler(void *cbData, const wchar_t *pszData, int nLength)
{
	CXmlSax *pClass = static_cast <CXmlSax *>(cbData);
	pClass->onCharacterData(pszData, nLength);
}

void wtw::CXmlSax::_processingInstructionHandler(void *cbData, const wchar_t *pszTarget, const wchar_t *pszData)
{
	CXmlSax *pClass = static_cast <CXmlSax *>(cbData);
	pClass->onProcessingInstruction(pszTarget, pszData);
}

void wtw::CXmlSax::_commentHandler(void *cbData, const wchar_t *pszData)
{
	CXmlSax *pClass = static_cast <CXmlSax *>(cbData);
	pClass->onComment(pszData);
}

void wtw::CXmlSax::_startCdataSectionHandler(void *cbData)
{
	CXmlSax *pClass = static_cast <CXmlSax *>(cbData);
	pClass->onStartCdataSection();
}

void wtw::CXmlSax::_endCdataSectionHandler(void *cbData)
{
	CXmlSax *pClass = static_cast <CXmlSax *>(cbData);
	pClass->onEndCdataSection();
}

void wtw::CXmlSax::_defaultHandler(void *cbData,
	const wchar_t *pszData, int nLength)
{
	CXmlSax *pClass = static_cast <CXmlSax *>(cbData);
	pClass->onDefault(pszData, nLength);
}

int wtw::CXmlSax::_externalEntityRefHandler(void *cbData, const wchar_t *pszContext, const wchar_t *pszBase, const wchar_t *pszSystemID, const wchar_t *pszPublicID)
{
	CXmlSax *pClass = static_cast <CXmlSax *>(cbData);
	return pClass->onExternalEntityRef(pszContext,
		pszBase, pszSystemID, pszPublicID) ? 1 : 0;
}

/*
 int __cdecl wtw::CXmlSax::_unknownEncodingHandler(void *cbData,
 const wchar_t *pszName, XML_Encoding *pInfo)
 {
 CXmlSax *pClass = static_cast <CXmlSax *> (cbData);
 return pClass->OnUnknownEncoding(pszName, pInfo) ? 1 : 0;
 }
 */

void wtw::CXmlSax::_startNamespaceDeclHandler(void *cbData, const wchar_t *pszPrefix, const wchar_t *pszURI)
{
	CXmlSax *pClass = static_cast <CXmlSax *>(cbData);
	pClass->onStartNamespaceDecl(pszPrefix, pszURI);
}

void wtw::CXmlSax::_endNamespaceDeclHandler(void *cbData, const wchar_t *pszPrefix)
{
	CXmlSax *pClass = static_cast <CXmlSax *>(cbData);
	pClass->onEndNamespaceDecl(pszPrefix);
}

void wtw::CXmlSax::_xmlDeclHandler(void *cbData, const wchar_t *pszVersion, const wchar_t *pszEncoding, int nStandalone)
{
	CXmlSax *pClass = static_cast <CXmlSax *>(cbData);
	pClass->onXmlDecl(pszVersion, pszEncoding, nStandalone != 0);
}

void wtw::CXmlSax::_startDoctypeDeclHandler(void *cbData, const wchar_t *pszDoctypeName, const wchar_t *pszSysID, const wchar_t *pszPubID, int nHasInternalSubset)
{
	CXmlSax *pClass = static_cast <CXmlSax *>(cbData);
	pClass->onStartDoctypeDecl(pszDoctypeName, pszSysID,
		pszPubID, nHasInternalSubset != 0);
}

void wtw::CXmlSax::_endDoctypeDeclHandler(void *cbData)
{
	CXmlSax *pClass = static_cast <CXmlSax *>(cbData);
	pClass->onEndDoctypeDecl();
}

